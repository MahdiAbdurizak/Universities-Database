﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Distance.BLL.DTO
{
   public class ФормаОбученияDTO
    {
        public int Код_ФормаОбуения { get; set; }
        public string Форма_Обучения { get; set; }
    }
}

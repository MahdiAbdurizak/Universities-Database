﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Distance.BLL.DTO
{
   public class УровеньОбученияDTO
    {
        public int Код_УровеньОбуения { get; set; }
        public string Уровень_Обучения { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Distance.DAL.Entities
{
   public class Специальности
    {
        [Key]
        public int Код_Специальности { get; set; }
        public string Специальность { get; set; }
        public string Сокр_название { get; set; }
        public string Код_Направление { get; set; }
        public string Направление { get; set; }
        public string Профиль { get; set; }
        public string Язык_Обуения { get; set; }
        public int Код_УровеньОбуения { get; set; }
        public int Код_ФормаОбуения { get; set; }
        public virtual УровеньОбучения Уровень_обуения { get; set; }
        public virtual ФормаОбучения Форма_обуения { get; set; }
        public virtual ICollection<Университеты> университеты { get; set; }

    }
}
